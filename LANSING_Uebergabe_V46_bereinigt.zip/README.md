# LANSING Bautagesbericht – technische Übergabe V46

## Zweck und vorhandener Stand
Statische Web-App zur Erstellung von Montage- und Bautagesberichten auf iPad/Safari. Die vorhandene `index.html` enthält das Formular für Projekt, Datum, Zeiten, ausgeführte und zusätzliche Arbeiten, besondere Vorkommnisse, Witterung, Mitarbeiter, Fotos und Unterschriften. Ein PDF-/Druckabschluss sowie KI-gestützte Diktatverarbeitung sind im Frontend vorgesehen. Die Funktionen wurden in dieser Übergabe **nicht vollständig praktisch getestet**.

## Technik und Dienste
HTML, CSS und JavaScript ohne mitgeliefertes Build-System oder Paketmanager; `sw.js` und `manifest.webmanifest` für PWA-/Offline-Funktion, `mitarbeiter.js` als Mitarbeiter-Auswahldatei, PNG-Icons. Externe Dienste: Open-Meteo (Wetter und Geocoding), Zippopotam.us (deutsche PLZ) und ein separater KI-Cloudflare-Worker. **Der Worker-Quellcode ist nicht Bestandteil dieser ZIP.** Keine Datenbankdatei und kein Datenbankschema enthalten.

## Installation und Start
1. ZIP in einen eigenen Ordner entpacken.
2. Für die statische Oberfläche lokal einen HTTP-Server starten, z. B. mit Python 3: `python -m http.server 8000` im Projektordner.
3. Im Browser `http://localhost:8000` öffnen. Für iPad/PWA und Service Worker ist ein geeigneter HTTPS-Host nötig. Ein lokaler Dateiaufruf (`file://`) ist für Service Worker ungeeignet.
4. Für KI-Funktionen den Platzhalter `__KI_WORKER_URL__` in `index.html` mit der URL des freigegebenen eigenen Backends ersetzen. Ohne funktionierendes Backend sind KI-Funktionen nicht einsatzbereit. Siehe `config.example.md`.
5. Vor produktivem Einsatz Funktionsprüfung mit ausschließlich fiktiven Daten durchführen.

## Daten und Berechtigungen
Der Frontend-Code verwendet Browser-`localStorage` für Formularzustände, darunter Unterschriftsinformationen und projektbezogene Wetterorte. Fotos und Berichte können im Browser verarbeitet bzw. als PDF ausgegeben werden. Ob weitere Speicherpfade oder serverseitige Speicherung existieren, muss anhand des fehlenden Worker-Backends geprüft werden. **Im gelieferten Frontend ist keine verifizierte serverseitige Benutzeranmeldung oder Rollen-/Rechteprüfung dokumentiert.** Keine echten personenbezogenen Daten in eine öffentliche Testinstanz eingeben.

## Sicherheit und Umfang
Dies ist eine bereinigte Übergabekopie der gelieferten V46. Die feste Worker-Adresse wurde durch einen Platzhalter ersetzt; keine echten Berichte, Fotos, Datenbank-Dumps oder Git-Historie enthalten. `mitarbeiter.js` ist auf vertrauliche Mitarbeiterangaben zu prüfen; die Übergabekopie enthält ausschließlich neutrale Platzhalter. Das ursprüngliche ZIP bleibt unverändert. Eine vollständige Sicherheitsfreigabe des nicht vorliegenden Backends ist unmöglich.

## Bekannte Einschränkungen / offene Punkte
- KI-Worker-Quellcode, serverseitige Konfiguration und ggf. Deployment-Anleitung fehlen.
- Diktierbuttons waren zuletzt als fehlerhaft gemeldet; nach Übergabe erneut testen.
- Offline-Verfügbarkeit und iPad-Safari-Verhalten müssen auf einem echten Gerät geprüft werden.
- Browser-PDF-Export, Unterschriften und Fotofunktion sind nicht end-to-end getestet.
- Keine automatisierten Tests, kein Build-Skript und kein Datenbankschema mitgeliefert.

## Spätere chayns-Einbindung – noch nicht umgesetzt
**Bestätigt:** statisches Frontend; Service Worker; externe Wetter-/PLZ-Schnittstellen; separater KI-Worker; Browser-Datenspeicherung und PDF-/Foto-/Unterschriftsfunktionen im Frontend.

**Offen mit NIEWOEHNER IT zu klären:** Hosting innerhalb oder außerhalb von chayns; geschützter Mitarbeiterzugang und Rechteprüfung; sichere Übergabe der Nutzeridentität; Mandanten-/Projekttrennung; Speicherung und Löschung von Berichten, Bildern und Unterschriften; Backend und dessen Geheimnisverwaltung; Upload- und Exportwege; HTTPS/PWA/Offline- und iPad-Kompatibilität; Datenschutz und Auftragsverarbeitung. Eine chayns-Kompatibilität ist **nicht geprüft**.
