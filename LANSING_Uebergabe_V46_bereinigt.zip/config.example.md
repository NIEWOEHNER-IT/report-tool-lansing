# Konfigurationsbeispiel

Die statische V46 enthält keine separate Laufzeit-Konfigurationsdatei. Für die KI-Diktatfunktion in `index.html` den Platzhalter `__KI_WORKER_URL__` durch die freigegebene HTTPS-URL eines eigenen Workers ersetzen. Die Originaladresse wurde in dieser öffentlichen Übergabekopie absichtlich entfernt. Keine API-Schlüssel in `index.html` eintragen.

Die Implementierung und die Geheimnisse des Workers gehören ausschließlich in dessen geschützte Server-Konfiguration.
