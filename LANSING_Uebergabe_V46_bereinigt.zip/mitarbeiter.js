// LANSING Mitarbeiterliste – Namen hier zwischen den Anführungszeichen bearbeiten.
// Du kannst weitere Namen ergänzen oder vorhandene Zeilen entfernen.
// Nach dem Bearbeiten speichern und die Website neu laden.
window.LANSING_MITARBEITER = [
  "Mitarbeiter 01",
  "Mitarbeiter 02",
  "Mitarbeiter 03",
  "Mitarbeiter 04",
  "Mitarbeiter 05",
  "Mitarbeiter 06",
  "Mitarbeiter 07",
  "Mitarbeiter 08",
  "Mitarbeiter 09",
  "Mitarbeiter 10"
];
